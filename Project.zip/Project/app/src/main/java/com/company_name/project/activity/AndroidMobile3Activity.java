/**
 *  Created by [Author].
 */

package com.company_name.project.activity;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.widget.Button;
import android.widget.ImageView;
import com.company_name.project.R;


public class AndroidMobile3Activity extends AppCompatActivity {
	
	public static Intent newIntent(Context context) {
	
		// Fill the created intent with the data you want to be passed to this Activity when it's opened.
		return new Intent(context, AndroidMobile3Activity.class);
	}
	
	private TextView step1HoldTheTraTextView;
	private TextView step2HoldTheButTextView;
	private TextView step3TapNextTextView;
	private Button nextButton;
	private ImageButton leftArrowButton;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.android_mobile3_activity);
		this.init();
	}
	
	private void init() {
	
		// Configure Step 1. Hold the Tra component
		step1HoldTheTraTextView = this.findViewById(R.id.step1_hold_the_tra_text_view);
		
		// Configure Step 2. Hold the But component
		step2HoldTheButTextView = this.findViewById(R.id.step2_hold_the_but_text_view);
		
		// Configure Step 3. Tap Next component
		step3TapNextTextView = this.findViewById(R.id.step3_tap_next_text_view);
		
		// Configure next component
		nextButton = this.findViewById(R.id.next_button);
		nextButton.setOnClickListener((view) -> {
	this.onNextPressed();
});
		
		// Configure left-arrow component
		leftArrowButton = this.findViewById(R.id.left_arrow_button);
		leftArrowButton.setOnClickListener((view) -> {
	this.onLeftArrowPressed();
});
	}
	
	public void onNextPressed() {
	
		this.startAndroidMobile1TwoActivity();
	}
	
	public void onLeftArrowPressed() {
	
		this.startAndroidMobile2Activity();
	}

	private void startAndroidMobile1TwoActivity() {

		this.startActivity(AndroidMobile1TwoActivity.newIntent(this));
	}



	private void startAndroidMobile2Activity() {
	
		this.startActivity(AndroidMobile2Activity.newIntent(this));
	}
	

}
