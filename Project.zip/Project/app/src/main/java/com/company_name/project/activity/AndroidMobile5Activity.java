/**
 *  Created by [Author].
 */

package com.company_name.project.activity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.ImageView;
import android.view.View;
import android.support.constraint.ConstraintLayout;
import com.company_name.project.R;
import android.widget.ImageButton;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;
import android.content.Context;


public class AndroidMobile5Activity extends AppCompatActivity {
	
	public static Intent newIntent(Context context) {
	
		// Fill the created intent with the data you want to be passed to this Activity when it's opened.
		return new Intent(context, AndroidMobile5Activity.class);
	}
	
	private ImageButton leftArrowButton;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.android_mobile5_activity);
		this.init();
	}
	
	private void init() {
	
		// Configure left-arrow component
		leftArrowButton = this.findViewById(R.id.left_arrow_button);
		leftArrowButton.setOnClickListener((view) -> {
	this.onLeftArrowPressed();
});
	}
	
	public void onLeftArrowPressed() {

		this.startAndroidMobile1Activity();

	}

	private void startAndroidMobile1Activity() {

		this.startActivity(AndroidMobile1Activity.newIntent(this));

	}
}
