/**
 *  Created by [Author].
 */

package com.company_name.project.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;
import com.company_name.project.R;
import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.widget.ImageButton;


public class AndroidMobile7Activity extends AppCompatActivity {
	
	public static Intent newIntent(Context context) {
	
		// Fill the created intent with the data you want to be passed to this Activity when it's opened.
		return new Intent(context, AndroidMobile7Activity.class);
	}
	
	private ImageButton leftArrowButton;
	private ImageButton group7Button;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.android_mobile7_activity);
		this.init();
	}
	
	private void init() {
	
		// Configure left-arrow component
		leftArrowButton = this.findViewById(R.id.left_arrow_button);
		leftArrowButton.setOnClickListener((view) -> {
	this.onLeftArrowPressed();
});


	}

	public void onLeftArrowPressed() {
	
		this.startAndroidMobile6Activity();
	}
	
	private void startAndroidMobile6Activity() {
	
		this.startActivity(AndroidMobile6Activity.newIntent(this));
	}
}
