/**
 *  Created by [Author].
 */

package com.company_name.project.activity;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import com.company_name.project.R;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageButton;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ImageView;
import android.support.constraint.ConstraintLayout;
import android.view.View;


public class AndroidMobile4Activity extends AppCompatActivity {
	
	public static Intent newIntent(Context context) {
	
		// Fill the created intent with the data you want to be passed to this Activity when it's opened.
		return new Intent(context, AndroidMobile4Activity.class);
	}
	
	private TextView step1HoldTheLocTextView;
	private TextView step2ClickTheBuTextView;
	private Button nextButton;
	private ImageButton leftArrowButton;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.android_mobile4_activity);
		this.init();
	}
	
	private void init() {
	
		// Configure Step 1. Hold the Loc component
		step1HoldTheLocTextView = this.findViewById(R.id.step1_hold_the_loc_text_view);
		
		// Configure Step 2. Click the Bu component
		step2ClickTheBuTextView = this.findViewById(R.id.step2_click_the_bu_text_view);
		
		// Configure next component
		nextButton = this.findViewById(R.id.next_button);
		nextButton.setOnClickListener((view) -> {
	this.onNextPressed();
});
		
		// Configure left-arrow component
		leftArrowButton = this.findViewById(R.id.left_arrow_button);
		leftArrowButton.setOnClickListener((view) -> {
	this.onLeftArrowPressed();
});
	}
	
	public void onNextPressed() {
	
		//this.startAndroidMobile1Activity();
	}
	
	public void onLeftArrowPressed() {
		this.startAndroidMobile2Activity();
	}
	
	private void startAndroidMobile2Activity() {
	
		this.startActivity(AndroidMobile2Activity.newIntent(this));
	}
}
