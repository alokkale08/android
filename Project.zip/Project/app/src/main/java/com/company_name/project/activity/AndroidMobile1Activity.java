/**
 *  Created by [Author].
 */

package com.company_name.project.activity;

import android.content.Intent;
import android.widget.LinearLayout;
import android.view.View;
import android.os.Bundle;
import android.widget.ImageButton;
import com.company_name.project.R;
import android.support.v7.app.AppCompatActivity;
import android.support.constraint.ConstraintLayout;
import android.widget.ImageView;
import android.content.Context;
import android.widget.TextView;


public class AndroidMobile1Activity extends AppCompatActivity {
	
	public static Intent newIntent(Context context) {
	
		// Fill the created intent with the data you want to be passed to this Activity when it's opened.
		return new Intent(context, AndroidMobile1Activity.class);
	}
	
	private ImageButton iconFeatherSettingButton;
	private LinearLayout viewButton;
	private ImageButton component21Button;
	private ImageButton group1Button;


	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.android_mobile1_activity);
		this.init();
	}
	
	private void init() {
	
		// Configure Icon feather-setting component
		iconFeatherSettingButton = this.findViewById(R.id.icon_feather_setting_button);
		iconFeatherSettingButton.setOnClickListener((view) -> {
	this.onIconFeatherSettingPressed();
});
		
		// Configure View component
		viewButton = this.findViewById(R.id.view_button);
		viewButton.setOnClickListener((view) -> {
	this.onViewPressed();
});
		
		// Configure Component 2 – 1 component
		component21Button = this.findViewById(R.id.component21_button);
		component21Button.setOnClickListener((view) -> {
	this.onComponent21Pressed();
});
		// Configure Component 2 – 1 component
		group1Button = this.findViewById(R.id.group1_button);
		group1Button.setOnClickListener((view) -> {
			this. onGroup1Pressed();
		});
	}
	
	public void onIconFeatherSettingPressed() {
	
		this.startAndroidMobile10Activity();
	}
	

	public void onViewPressed() {

		this.startAndroidMobile6Activity();
	}


	private void startAndroidMobile6Activity() {
		this.startActivity(AndroidMobile6Activity.newIntent(this));

	}

	public void onComponent21Pressed() {
	
		this.startAndroidMobile2Activity();
	}
	
	private void startAndroidMobile2Activity() {
	
		this.startActivity(AndroidMobile2Activity.newIntent(this));
	}
	
	private void startAndroidMobile10Activity() {
	
		this.startActivity(AndroidMobile10Activity.newIntent(this));
	}
	public void onGroup1Pressed(){

		this.startAndroidMobile9Activity();
	}

	private void startAndroidMobile9Activity() {
		this.startActivity(AndroidMobile9Activity.newIntent(this));

	}
}
